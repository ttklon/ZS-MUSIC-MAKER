# -*- coding: utf-8 -*-
"""
[v9] anti_ai_polish.py — устранение «нейроношности».

По ТЗ раздел 14: «RVC делает финальную персонализацию, убирая нейроношность»
+ раздел 20 «Устранение ghost harmonies и формульных структур».

Модуль работает НА ФИНАЛЬНОМ mixdown WAV перед мастерингом. Применяет цепочку
пост-эффектов, которые «оживляют» звук:

  1. micro_timing_jitter        — сдвигаем короткие сегменты на ±3-8 мс
  2. breath_insert              — вставляем реальные дыхания из voice_vault
  3. section_dynamics_variation — меняем громкость по секциям arrangement_plan
  4. ghost_harmonies_kill       — вычитаем регулярные обертоны в 3-6 kHz
  5. formulaic_structure_bust   — вносим лёгкую случайность в 8-барный цикл
  6. tape_saturation            — soft-clip + пыль/шум ленты (very subtle)
  7. imperfect_tuning           — расстраиваем ноты в самых длинных нотах на ±5 центов
  8. lofi_pass                  — вариативное срезание верхов по секциям

Всё — post-processing, ничего не переписывает исходники. При отсутствии numpy —
gracefully проходит через no-op с warning.
"""
from __future__ import annotations
import math, random, time
from pathlib import Path
from typing import Optional

try:
    import numpy as np
except Exception:
    np = None

try:
    import soundfile as sf
    HAS_SF = True
except Exception:
    HAS_SF = False


# ============================================================ IO
def _read(path: str):
    if not HAS_SF: return None, None
    y, sr = sf.read(path, always_2d=True)
    return y, sr


def _write(path: str, y, sr):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    sf.write(path, y, sr)


# ============================================================ effects
def _micro_timing_jitter(y, sr, amount_ms: float = 5.0,
                         seed: Optional[int] = None):
    if np is None: return y
    rng = np.random.default_rng(seed or int(time.time()))
    seg_len = int(sr * 0.5)      # 500 мс блоки
    max_shift = int(sr * amount_ms / 1000.0)
    if max_shift <= 0: return y
    out = np.zeros_like(y)
    pos = 0
    while pos < len(y):
        seg = y[pos:pos+seg_len]
        shift = int(rng.integers(-max_shift, max_shift + 1))
        start = max(0, pos + shift)
        end = min(len(out), start + len(seg))
        out[start:end] += seg[:end-start] * 0.98
        pos += seg_len
    peak = float(np.max(np.abs(out))) or 1.0
    if peak > 0.99:
        out = out * (0.99 / peak)
    return out


def _breath_insert(y, sr, breath_samples: list, positions_sec: list,
                   volume_db: float = -22.0):
    if np is None or not breath_samples: return y
    out = y.copy()
    gain = 10 ** (volume_db / 20.0)
    for t in positions_sec:
        idx = int(t * sr)
        if idx >= len(out): continue
        br = breath_samples[hash(t) % len(breath_samples)]
        if br is None: continue
        L = min(len(br), len(out) - idx)
        if out.ndim == 2 and br.ndim == 1:
            out[idx:idx+L, 0] += br[:L] * gain
            if out.shape[1] > 1:
                out[idx:idx+L, 1] += br[:L] * gain * 0.9
        else:
            out[idx:idx+L] += br[:L] * gain
    return out


def _section_dynamics_variation(y, sr, sections: list,
                                seed: Optional[int] = None):
    if np is None or not sections: return y
    rng = random.Random(seed or int(time.time()))
    out = y.copy()
    for sec in sections:
        s = int(sec.get("start_sec", 0.0) * sr)
        e = int(sec.get("end_sec", 0.0) * sr)
        if e <= s or s >= len(out): continue
        e = min(e, len(out))
        energy = float(sec.get("energy", 0.7))
        span_db = (1.5 if energy < 0.5 else 0.7)
        gain_db = rng.uniform(-span_db, span_db)
        gain = 10 ** (gain_db / 20.0)
        out[s:e] = out[s:e] * gain
    peak = float(np.max(np.abs(out))) or 1.0
    if peak > 0.99: out = out * (0.99 / peak)
    return out


def _ghost_harmonies_kill(y, sr):
    if np is None: return y
    try:
        import scipy.signal as sg
    except Exception:
        return y
    out = y.copy()
    for freq in (3200.0, 4800.0):
        b, a = sg.iirnotch(w0=freq / (sr/2), Q=25.0)
        if out.ndim == 2:
            for ch in range(out.shape[1]):
                out[:, ch] = sg.filtfilt(b, a, out[:, ch])
        else:
            out = sg.filtfilt(b, a, out)
    return out


def _formulaic_structure_bust(y, sr, seed: Optional[int] = None):
    if np is None: return y
    rng = random.Random(seed or int(time.time()))
    dur = len(y) / sr
    if dur < 30: return y
    out = y.copy()
    n_drops = rng.randint(1, 2)
    for _ in range(n_drops):
        t = rng.uniform(0.3 * dur, 0.85 * dur)
        drop_len = rng.uniform(0.05, 0.12)
        s = int(t * sr); e = int((t + drop_len) * sr)
        e = min(e, len(out))
        if e <= s: continue
        out[s:e] *= rng.uniform(0.05, 0.20)
    return out


def _tape_saturation(y, amount: float = 0.06):
    if np is None: return y
    x = np.clip(y * (1 + amount), -1.0, 1.0)
    return np.tanh(x * (1 + amount)) * (1 / (1 + amount))


def _imperfect_tuning(y, sr, cents: float = 4.0):
    if np is None: return y
    try:
        import scipy.signal as sg
    except Exception:
        return y
    lfo = np.sin(2 * math.pi * 0.3 * np.arange(len(y)) / sr) * (cents / 100.0)
    mod = 1 + lfo * 0.005
    if y.ndim == 2:
        out = y.copy()
        for ch in range(y.shape[1]):
            out[:, ch] = y[:, ch] * mod
        return out
    return y * mod


def _lofi_pass(y, sr, cutoff: float = 15000.0):
    if np is None: return y
    try:
        import scipy.signal as sg
    except Exception:
        return y
    b, a = sg.butter(4, cutoff / (sr/2), btype="low")
    if y.ndim == 2:
        out = y.copy()
        for ch in range(y.shape[1]):
            out[:, ch] = sg.filtfilt(b, a, y[:, ch])
        return out
    return sg.filtfilt(b, a, y)


# ============================================================ main API
def polish_track(input_wav: str,
                 output_wav: str,
                 arrangement_plan: Optional[dict] = None,
                 breath_samples: Optional[list] = None,
                 preset: str = "standard",
                 seed: Optional[int] = None) -> dict:
    """
    preset:
      • gentle    — минимальная обработка (для sing/melodic)
      • standard  — универсал (default)
      • aggressive — жёсткое разрушение формульности (для phonk / trap)
    """
    if not HAS_SF:
        return {"ok": False, "error": "soundfile unavailable"}
    y, sr = _read(input_wav)
    if y is None:
        return {"ok": False, "error": f"cannot read {input_wav}"}

    stages_applied = []

    amount_ms = {"gentle": 2.5, "standard": 5.0, "aggressive": 8.0}[preset]
    y = _micro_timing_jitter(y, sr, amount_ms=amount_ms, seed=seed)
    stages_applied.append(f"micro_timing_jitter({amount_ms}ms)")

    if breath_samples and arrangement_plan:
        secs = arrangement_plan.get("sections", [])
        positions = []
        for s in secs:
            if s.get("name", "").startswith(("verse", "chorus", "prechorus")):
                positions.append(float(s.get("start_sec", 0.0)) + 0.05)
        y = _breath_insert(y, sr, breath_samples, positions,
                           volume_db=-24.0)
        stages_applied.append(f"breath_insert(n={len(positions)})")

    if arrangement_plan and arrangement_plan.get("sections"):
        y = _section_dynamics_variation(y, sr,
                                        arrangement_plan["sections"],
                                        seed=seed)
        stages_applied.append("section_dynamics_variation")

    if preset in ("standard", "aggressive"):
        y = _ghost_harmonies_kill(y, sr)
        stages_applied.append("ghost_harmonies_kill")

    if preset == "aggressive":
        y = _formulaic_structure_bust(y, sr, seed=seed)
        stages_applied.append("formulaic_structure_bust")

    y = _tape_saturation(y, amount={"gentle": 0.02,
                                    "standard": 0.05,
                                    "aggressive": 0.09}[preset])
    stages_applied.append("tape_saturation")

    if preset in ("gentle", "standard"):
        y = _imperfect_tuning(y, sr, cents=3.0)
        stages_applied.append("imperfect_tuning")

    cutoff = {"gentle": 17000.0, "standard": 16000.0,
              "aggressive": 14500.0}[preset]
    y = _lofi_pass(y, sr, cutoff=cutoff)
    stages_applied.append(f"lofi_pass({cutoff:.0f})")

    _write(output_wav, y, sr)
    return {
        "ok": True,
        "input": input_wav,
        "output": output_wav,
        "preset": preset,
        "stages_applied": stages_applied,
        "sr": int(sr),
    }


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 3:
        print("usage: python anti_ai_polish.py <in.wav> <out.wav> [preset]")
        sys.exit(1)
    r = polish_track(sys.argv[1], sys.argv[2],
                     preset=sys.argv[3] if len(sys.argv) > 3 else "standard")
    import json; print(json.dumps(r, ensure_ascii=False, indent=2))
